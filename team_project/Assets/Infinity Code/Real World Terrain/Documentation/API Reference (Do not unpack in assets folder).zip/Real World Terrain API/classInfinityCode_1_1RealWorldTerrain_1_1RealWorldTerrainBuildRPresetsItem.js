var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRPresetsItem =
[
    [ "facade", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRPresetsItem.html#aac3c295fac456e90829f2d4a4ef02128", null ],
    [ "roof", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRPresetsItem.html#a008d1a16187ed9ea03beecf385e2e9b4", null ],
    [ "texture", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRPresetsItem.html#a7824d2460f97965124eb5b6d1654dbd0", null ]
];