var searchData=
[
  ['url_969',['url',['../classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainGooglePlaceDetailsResult.html#a6ff6ad62342e291b8fc6a69c89abb0cf',1,'InfinityCode::RealWorldTerrain::Webservices::Results::RealWorldTerrainGooglePlaceDetailsResult']]],
  ['utc_5foffset_970',['utc_offset',['../classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainGooglePlaceDetailsResult.html#ab40c90c0437ff45b5c7a8384554f9c73',1,'InfinityCode::RealWorldTerrain::Webservices::Results::RealWorldTerrainGooglePlaceDetailsResult']]],
  ['uvoffset_971',['uvOffset',['../classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#af19eb3b45e222b6ba2210b462aad9edf',1,'InfinityCode::RealWorldTerrain::RealWorldTerrainBuilding']]]
];
