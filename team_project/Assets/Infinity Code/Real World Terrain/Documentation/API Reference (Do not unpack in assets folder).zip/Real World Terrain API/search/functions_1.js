var searchData=
[
  ['bounds_593',['Bounds',['../classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Bounds.html#ab9cc0363d80abc35594f19fe9647c360',1,'InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Bounds.Bounds(RealWorldTerrainXML node)'],['../classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Bounds.html#a91ca5fb70697a57b28f70d92da267f9c',1,'InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Bounds.Bounds(double minlon, double minlat, double maxlon, double maxlat)']]]
];
