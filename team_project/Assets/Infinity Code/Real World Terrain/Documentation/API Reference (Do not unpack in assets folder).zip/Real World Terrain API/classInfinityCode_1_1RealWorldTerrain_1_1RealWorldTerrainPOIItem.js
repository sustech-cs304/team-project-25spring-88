var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem =
[
    [ "SetPrefs", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#ac831d134ddc18e85e2f2531cb6b473ae", null ],
    [ "altitude", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a0be786066f5333aa9b629419efa7253d", null ],
    [ "title", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a2bc36c16fde84ff10d896f0e9b58e391", null ],
    [ "x", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a91ce2723d58ba778398064de79538529", null ],
    [ "y", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a0cd6366a3b7340da2503b4ec98ca6c51", null ]
];